class Node {
    constructor(data) {
        this.data=data;
        this.next=null;
    }
}

class SLL { 
    constructor() {
        this.head=null;
    }
    addFront(value) {
        let new_node=new Node(value);
        if(!this.head) {
            this.head=new_node;
            return this.head;
        }
        new_node.next=this.head;
        this.head=new_node;
        return this.head;
    }

    removeFront() {
        if(!this.head) {
            return null;
        }
        let removed_node=this.head;
        
        this.head=this.head.next;
        
        removed_node.next=null;
        return this.head;

    }

    front() {
        if(!this.head) {
            return null;
        }

        return this.head.data;
    }
}

SLL1 = new SLL();
